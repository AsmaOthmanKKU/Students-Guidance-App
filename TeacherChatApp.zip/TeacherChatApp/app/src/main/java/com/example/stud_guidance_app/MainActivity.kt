package com.example.stud_guidance_app

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.example.stud_guidance_app.fragment.MyAccountFragment
import com.example.stud_guidance_app.fragment.PeopleFragment
import com.example.stud_guidance_app.util.FirestoreUtil
import com.firebase.ui.auth.AuthUI
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_my_account.*
import kotlinx.android.synthetic.main.fragment_my_account.view.*
import org.jetbrains.anko.startActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status("online")
        replaceFragment(PeopleFragment())

        navigation.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.navigation_people -> {
                    replaceFragment(PeopleFragment())
                    true
                }
                R.id.navigation_my_account -> {
                    replaceFragment(MyAccountFragment())
                    true
                }
                else -> false
            }
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_layout, fragment)
                .commit()
    }

    override fun onResume() {
        super.onResume()
        if (FirebaseAuth.getInstance().currentUser != null){
            status("online")
            Log.e("status","online")

        }

    }

    override fun onPause() {
        super.onPause()
        super.onResume()
        if (FirebaseAuth.getInstance().currentUser != null){
            status("offline")
            Log.e("status","offline")

        }
    }



    fun status(status: String){

        FirestoreUtil.updateCurrentUser(FirebaseAuth.getInstance().currentUser?.displayName ?: "",
                FirebaseAuth.getInstance().currentUser?.displayName ?: "",status, "fail")
    }
}
