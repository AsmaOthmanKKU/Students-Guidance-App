package com.example.stud_guidance_app

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Patterns
import android.widget.Toast
import com.example.stud_guidance_app.service.MyFirebaseInstanceIDService
import com.example.stud_guidance_app.util.FirestoreUtil
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.iid.FirebaseInstanceId
import kotlinx.android.synthetic.main.activity_login_stud.*
import org.jetbrains.anko.clearTask
import org.jetbrains.anko.indeterminateProgressDialog
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.newTask

class LoginStud : AppCompatActivity() {
    var authLog: FirebaseAuth? = null

    lateinit var auth: FirebaseAuth
// ...
// Initialize Firebase Auth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_stud)
        if(intent.hasExtra("KeyStud")){}
        authLog = FirebaseAuth.getInstance()

        TLRpass.setOnClickListener {
            //startActivity(Intent(this, ResetPass::class.java))
        }
        TLsignup.setOnClickListener {
            startActivity(Intent(this, RegisterStud::class.java))
        }
        BLsignin.setOnClickListener {
            val email = ELemail.text.toString()
            val password = ELpass.text.toString()
            if(email.isEmpty()){
                Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                Toast.makeText(this, "Enter Valid Email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(password.isEmpty()){
                Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            logUser()
        }
    }

    private fun logUser() {
        authLog = FirebaseAuth.getInstance()
        val email = ELemail.text.toString()
        val password = ELpass.text.toString()

        authLog?.signInWithEmailAndPassword(email,password)
             Toast.makeText(this, "Successful Log in", Toast.LENGTH_SHORT).show()
        val progressDialog = indeterminateProgressDialog("Setting up your account")
        FirestoreUtil.initCurrentUserIfFirstTime {
            startActivity(intentFor<MainActivity>().newTask().clearTask())

            val registrationToken = FirebaseInstanceId.getInstance().token
            MyFirebaseInstanceIDService.addTokenToFirestore(registrationToken)

            progressDialog.dismiss()
        }

        }
}