package com.example.stud_guidance_app

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import com.example.stud_guidance_app.model.User
import com.example.stud_guidance_app.service.MyFirebaseInstanceIDService
import com.example.stud_guidance_app.util.FirestoreUtil
import com.google.firebase.auth.ActionCodeSettings
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.iid.FirebaseInstanceId
import kotlinx.android.synthetic.main.activity_register_stud.*
import org.jetbrains.anko.clearTask
import org.jetbrains.anko.indeterminateProgressDialog
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.newTask

class RegisterStud : AppCompatActivity() {
    var authReg: FirebaseAuth? = null
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_stud)
        authReg = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        TRsignIn.setOnClickListener {
            startActivity(Intent(this, SplashActivity::class.java))
        }

        BRsignup.setOnClickListener {
            val email = Remail.text.toString()
            val password = Rpass.text.toString()
            val username = Rname.text.toString()
            val numPhone = Rnumber.text.toString()

            if (username.isEmpty()) {
                Toast.makeText(this, "Please Enter Username", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(username.length>10){
                Toast.makeText(this, "Username Should be Less Than 10 Character", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (email.isEmpty()) {
                Toast.makeText(this, "Please Enter Email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Please Enter Valid Email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(numPhone.isEmpty()){
                Toast.makeText(this, "Please Enter Phone Number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(numPhone.length != 10){
                Toast.makeText(this, "Phone Number Should be 10 Numbers", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                Toast.makeText(this, "Please Enter Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (password.length < 8) {
                Toast.makeText(this, "The Password very short, Please Enter Password more than 8 Character And Digit", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            CreateUser()
        }

    }

    private fun CreateUser() {
        authReg = FirebaseAuth.getInstance()
        var email =Remail.text.toString()
        var password = Rpass.text.toString()
        val username = Rname.text.toString()
        val numPhone = Rnumber.text.toString()

        authReg?.createUserWithEmailAndPassword(email,password)

        val docRef = db.collection("users").document()
        val newUser = User(username, numPhone,"offline","student", null, mutableListOf())
         docRef.set(newUser).addOnSuccessListener {

        }

        val auth = FirebaseAuth.getInstance()
        val user = auth.currentUser

        user?.sendEmailVerification()
                ?.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.e("SignUp", "Email sent.")
                    }
                }

        Toast.makeText(this, "Email Verification send Successful",Toast.LENGTH_LONG).show()
        val launchIntent = packageManager.getLaunchIntentForPackage("com.example.stud_guidance_app")
        startActivity(launchIntent)
        val intent = Intent(this, SplashActivity::class.java)
        startActivity(intent)
        finish()




    }

}

