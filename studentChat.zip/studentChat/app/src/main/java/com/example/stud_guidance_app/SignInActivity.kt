package com.example.stud_guidance_app

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.ErrorCodes
import com.firebase.ui.auth.IdpResponse
import com.google.firebase.iid.FirebaseInstanceId
import com.example.stud_guidance_app.service.MyFirebaseInstanceIDService
import com.example.stud_guidance_app.util.FirestoreUtil
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_sign_in.*
import org.jetbrains.anko.clearTask
import org.jetbrains.anko.design.longSnackbar
import org.jetbrains.anko.indeterminateProgressDialog
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.newTask

class SignInActivity : AppCompatActivity() {

    private val RC_SIGN_IN = 1

    private val signInProviders =
            listOf(AuthUI.IdpConfig.EmailBuilder()
                    .setAllowNewAccounts(true)
                    .setRequireName(true)
                    .build())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        val auth = FirebaseAuth.getInstance()
        Log.e("SignUp","signInProviders auth.currentUser "+auth.currentUser)
        Log.e("SignUp"," signInProviders auth.currentUser displayName "+auth.currentUser?.displayName)

        account_sign_in.setOnClickListener {
            val intent = AuthUI.getInstance().createSignInIntentBuilder()
                    .setAvailableProviders(signInProviders)
                    .setLogo(R.drawable.logooooo)
                    .build()
            startActivityForResult(intent, RC_SIGN_IN)

        }

        Explogin.setOnClickListener {
            val intent = AuthUI.getInstance().createSignInIntentBuilder()
                        .setAvailableProviders(signInProviders)
                        .setLogo(R.drawable.logooooo)
                        .build()
                startActivityForResult(intent, RC_SIGN_IN)

            /*startActivity(Intent(this, LoginStud::class.java))
            finish()*/

        }

        Stdlogin.setOnClickListener {
            /*val intent = AuthUI.getInstance().createSignInIntentBuilder()
                    .setAvailableProviders(signInProviders)
                    .setLogo(R.drawable.logooooo)
                    .build()
            startActivityForResult(intent, RC_SIGN_IN)*/
            startActivity(Intent(this, RegisterStud::class.java))
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val response = IdpResponse.fromResultIntent(data)

            if (resultCode == Activity.RESULT_OK) {
                 lateinit var db: FirebaseFirestore

             /*   val auth = FirebaseAuth.getInstance()
              if(auth.currentUser?.isEmailVerified!!){
                  Log.e("SignUp","trueeeeeeeeee ")

              }else
              {
                  Log.e("SignUp","false ")
              //    Toast.makeText(this, "Please Verify Your Email Id First", Toast.LENGTH_SHORT).show()
                  auth.currentUser?.sendEmailVerification()
              }*/
                val progressDialog = indeterminateProgressDialog("Setting up your account")
                FirestoreUtil.initCurrentUserIfFirstTime {
                    startActivity(intentFor<MainActivity>().newTask().clearTask())

                    val registrationToken = FirebaseInstanceId.getInstance().token
                    MyFirebaseInstanceIDService.addTokenToFirestore(registrationToken)
                    progressDialog.dismiss()
                }

            }
            else if (resultCode == Activity.RESULT_CANCELED) {
                if (response == null) return

                when (response.error?.errorCode) {
                    ErrorCodes.NO_NETWORK ->
                            longSnackbar(constraint_layout, "No network")
                    ErrorCodes.UNKNOWN_ERROR ->
                        longSnackbar(constraint_layout, "Unknown error")
                }
            }
        }
    }
}
