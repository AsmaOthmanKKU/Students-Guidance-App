package com.example.stud_guidance_app.model


data class ChatChannel(val userIds: MutableList<String>) {
    constructor() : this(mutableListOf())
}