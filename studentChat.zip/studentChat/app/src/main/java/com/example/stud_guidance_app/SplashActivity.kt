package com.example.stud_guidance_app

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import org.jetbrains.anko.startActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lateinit var auth: FirebaseAuth
        auth = FirebaseAuth.getInstance()
        Log.e("SignUp","auth.currentUser outer "+auth.currentUser)

        if (FirebaseAuth.getInstance().currentUser == null){
            startActivity<SignInActivity>()
            finish()
        }
        else{
            val auth = FirebaseAuth.getInstance()
            Log.e("SignUp","auth.currentUser "+auth.currentUser)
            Log.e("SignUp","auth.currentUser displayName "+auth.currentUser?.displayName)
            Log.e("SignUp","auth.currentUser displayName auth.currentUser?.isEmailVerified "+auth.currentUser?.isEmailVerified)

             if(auth.currentUser?.isEmailVerified!!){
                 Log.e("SignUp","trueeeeeeeeee ")

             }else
             {
                 Log.e("SignUp","false ")
               //  auth.currentUser?.sendEmailVerification()
             }

            startActivity<MainActivity>()
            finish()
        }
        finish()
    }
}
