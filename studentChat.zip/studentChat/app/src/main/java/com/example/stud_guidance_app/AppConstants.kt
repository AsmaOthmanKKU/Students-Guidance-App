package com.example.stud_guidance_app


object AppConstants {
    const val USER_NAME = "USER_NAME"
    const val USER_ID = "USER_ID"
    const val USER_STATUS = "USER_STATUS"
   public const val USER_FUlLNAME = "Enter Your Name"
   public const val USER_PHONE = "Enter your Phone Number"



}