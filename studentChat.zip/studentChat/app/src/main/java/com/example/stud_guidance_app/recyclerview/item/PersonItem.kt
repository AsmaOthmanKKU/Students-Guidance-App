package com.example.stud_guidance_app.recyclerview.item

import android.content.Context
import android.view.View
import com.example.stud_guidance_app.R
import com.example.stud_guidance_app.glide.GlideApp
import com.example.stud_guidance_app.model.User
import com.example.stud_guidance_app.util.StorageUtil
import com.xwray.groupie.kotlinandroidextensions.Item
import com.xwray.groupie.kotlinandroidextensions.ViewHolder
import kotlinx.android.synthetic.main.item_person.*
import org.jetbrains.anko.textColor


class PersonItem(val person: User,
                 val userId: String,
                 private val context: Context)
    : Item() {

    override fun bind(viewHolder: ViewHolder, position: Int) {

        viewHolder.textView_name.text = person.name
        viewHolder.textView_bio.text = person.bio
        viewHolder.textView_online.text = person.status
        viewHolder.imageView_profile_picture.setImageResource(R.drawable.ic_profile)

       /* if(!person.type.equals("student"))
        {
            viewHolder.textView_name.text = person.name
            viewHolder.textView_bio.text = person.bio
            viewHolder.textView_online.text = person.status
            viewHolder.imageView_profile_picture.setImageResource(R.drawable.ic_profile)
        }else{
            viewHolder.cardView_item_person.visibility=View.GONE

        }*/


           /* GlideApp.with(context)
                    .load("https://www.google.com/imgres?imgurl=https")
                    .placeholder(R.drawable.ic_account_circle_black_24dp)
                    .into(viewHolder.imageView_profile_picture)*/
    }

    override fun getLayout() = R.layout.item_person
}