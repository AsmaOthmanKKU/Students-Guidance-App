package com.example.stud_guidance_app.model


data class User(val name: String,
                val bio: String,
                val status: String,
                val type: String,
                val profilePicturePath: String?,
                val registrationTokens: MutableList<String>) {
    constructor(): this("", "","", "",null, mutableListOf())
}